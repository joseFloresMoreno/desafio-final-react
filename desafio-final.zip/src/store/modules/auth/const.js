export const AUTH_LOGIN_START = 'AUTH_LOGIN_START';
export const AUTH_LOGIN_OK = 'AUTH_LOGIN_OK';
export const AUTH_LOGIN_NOK = 'AUTH_LOGIN_NOK';

export const AUTH_LOGOUT = 'AUTH_LOGOUT';