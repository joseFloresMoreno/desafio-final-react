import React from 'react';
import { Link } from 'react-router-dom';
import Card from '../../components/card/Card';

const Home = () => {
    return (
        <div className="home">
            <Card />
        </div>
    );
}
export default Home;