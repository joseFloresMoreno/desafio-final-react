import React, { useEffect, useState } from 'react';
import {  useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { Container, Button, Table } from 'reactstrap';
import PostModal from '../../components/post-modal/PostModal';

import { findAllAsyncActionCreator, findByIdAsyncActionCreator } from '../../store/modules/post/actions';

const TablePost = () => {
    const dispatch = useDispatch();
    const postModule = useSelector(store => store.post.posts);
    const postByIdModule = useSelector(store => store.post.postById);
    useEffect(() => {
        dispatch(findAllAsyncActionCreator());
    }, []);

    const handlerFindById = (post) => {
        return (event) => {
            dispatch(findByIdAsyncActionCreator(post.id));
        }
    }
        return (
            <Container>
            <Table
                striped
                hover
                responsive
            >
                
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Título</th>
                        <th>Descripción</th>
                        <th>Imagen</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {postModule.data.map(post => (
                        <tr key={post.id}>
                            <td>{post.id}</td>
                            <td>{post.title}</td>
                            <td>{post.description}</td>
                            <td><img src={post.image_url} /></td>
                            <td><Button onClick={handlerFindById(post)}>Ver</Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
            {postByIdModule.data.id && (<PostModal post={postByIdModule} />)}
            </Container>
        );
}

export default TablePost;