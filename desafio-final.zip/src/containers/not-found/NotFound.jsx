import React from 'react';

const NotFound = () => (404);

export default NotFound;