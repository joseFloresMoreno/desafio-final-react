import React, { useEffect, useState } from 'react';
import {  useDispatch, useSelector } from 'react-redux';
import { Container } from 'reactstrap';
import TablePost from '../../components/table/Table';

import { findAllAsyncActionCreator, findByIdAsyncActionCreator } from '../../store/modules/user/actions';


const PrivateHome = () => {
    const dispatch = useDispatch();
    const userModule = useSelector(store => store.user.users);
    const userByIdModule = useSelector(store => store.user.userById);
    useEffect(() => {
        dispatch(findAllAsyncActionCreator());
    }, []);

    const handlerFindById = (user) => {
        return (event) => {
            dispatch(findByIdAsyncActionCreator(user.id));
        }
    }

    return (
        <Container className="private-home">
            <h1>Lista de Post</h1>
            <br />
            <TablePost />
        </Container>
    );
};

export default PrivateHome;